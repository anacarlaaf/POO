# Personal Finance System Data Model



